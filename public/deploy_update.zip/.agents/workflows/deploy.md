---
description: Cara deploy perubahan dari localhost ke hosting perguruanpembda.com
---

# Workflow Deploy Pembda Hub

## Prasyarat
- Localhost: XAMPP (MySQL aktif)
- Hosting: Hostinger (perguruanpembda.com)
- Git sudah terhubung ke GitHub (YulianusZega/pembdahub)

## Alur Update dari Localhost ke Hosting

### Langkah 1: Selesaikan Perbaikan di Localhost
Pastikan Anda sudah menguji perubahan di browser localhost dan semua berfungsi normal.

### Langkah 2: Build Aset CSS/JS (WAJIB jika ada perubahan CSS atau JavaScript)
// turbo
```powershell
npm run build
```
> **Catatan:** Jika perubahan Anda HANYA di file PHP/Blade (bukan CSS/JS), langkah ini boleh dilewati.

### Langkah 3: Commit dan Push ke GitHub
// turbo
```powershell
git add .
git commit -m "Deskripsi perubahan Anda"
git push origin main
```

### Langkah 4: Deploy di Hosting Hostinger
1. Login ke **hPanel Hostinger** (hpanel.hostinger.com)
2. Masuk ke menu **Advanced** > **Git**
3. Klik tombol **Deploy** pada repository `pembdahub`
4. Jika Deploy **GAGAL** atau Macet (kode tidak berubah):
   
   **Opsi A (Paling Direkomendasikan): Reset Git Hostinger**
   - Di menu Git Hostinger, hapus repository `pembdahub` (klik ikon tempat sampah). Data database aman.
   - Tambahkan ulang repository `YulianusZega/pembdahub` (Branch: `main`, Path: `public_html/pembdahub`).
   - Hostinger akan melakukan *fresh clone* (mengunduh ulang seluruh kode dari nol secara bersih).
   
   **Opsi B (Cara Manual Aman - Full Backup ZIP)**
   - Buka Terminal di VSCode (di folder pembdahub lokal), jalankan perintah:
     `git archive -o full_backup.zip HEAD`
   - Buka File Manager Hostinger, unggah `full_backup.zip` ke dalam folder `public_html/pembdahub/`.
   - Ekstrak file tersebut dan pilih **"Replace / Overwrite"**. Ini 100% aman karena ZIP ini berisi seluruh file kode utuh.
   - (⚠️ PENTING: JANGAN pernah mengekstrak ZIP yang hanya berisi *sebagian* file baru lalu memilih "Replace" di Hostinger, karena Hostinger akan menghapus file lama yang tidak ada di ZIP).

### Langkah 5: Copy File Build ke Folder Public (Jika ada perubahan CSS/JS)
1. Buka **File Manager** Hostinger
2. Masuk ke `public_html/pembdahub/public/build/`
3. Copy folder `assets` dan file `manifest.json` ke `public_html/pembdahub/public/build/`
   (Seharusnya otomatis jika Deploy berhasil)

### Langkah 6: Bersihkan Cache (WAJIB setelah setiap Deploy)
1. Buka **File Manager** Hostinger
2. Masuk ke folder `public_html/pembdahub/bootstrap/cache/`
3. Hapus semua file di dalamnya (config.php, packages.php, services.php)
4. Biarkan folder cache tetap ada (kosong)

---

## PERINGATAN PENTING

### File `.env` (JANGAN PERNAH DIUBAH VIA GIT)
File `.env` di localhost dan hosting BERBEDA. Masing-masing sudah dikonfigurasi untuk lingkungannya sendiri:

**Localhost (.env):**
- `DB_DATABASE=pembda_hub`
- `DB_USERNAME=root`
- `DB_PASSWORD=` (kosong)

**Hosting (.env):**
- `DB_DATABASE=u474310197_pembdahub_db`
- `DB_USERNAME=u474310197_pembdahub_user`
- `DB_PASSWORD="#P3lit431"` ← HARUS PAKAI TANDA KUTIP karena ada karakter #

### Password Database di `.env` Hosting
Jika password database mengandung karakter spesial seperti `#`, `$`, `!`, WAJIB dibungkus dengan tanda kutip ganda (`"`).
- ❌ Salah: `DB_PASSWORD=#P3lit431`
- ✅ Benar: `DB_PASSWORD="#P3lit431"`

### Foto dan Gambar
Foto siswa/guru yang diupload melalui aplikasi TIDAK ikut masuk ke GitHub.
Jika Anda menambah foto baru di localhost, harus diupload manual ke folder:
`public_html/storage/` di hosting Hostinger.

### File `bootstrap/app.php` di Hosting
File ini di hosting memiliki baris tambahan:
```php
->registered(function ($app) {
    $app->usePublicPath(path: realpath(__DIR__.'/../../'));
})
```
Jika Deploy menimpa file ini, tambahkan kembali baris di atas sebelum `->create()`.

---

## Checklist Sebelum Deploy
- [ ] Perubahan sudah ditest di localhost
- [ ] `npm run build` sudah dijalankan (jika ada perubahan CSS/JS)
- [ ] `git add .` dan `git commit` sudah dilakukan
- [ ] `git push origin main` berhasil
- [ ] Klik Deploy di hPanel Hostinger
- [ ] Hapus isi folder `bootstrap/cache/` di hosting
- [ ] Cek website di browser (Ctrl+F5 untuk hard refresh)
